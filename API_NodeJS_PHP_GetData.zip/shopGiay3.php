<?php
//thong tin server
$svr="localhost";$u="id10840443_user";$p="12345678Aa@123";
$dbname="id10840443_springbootdb";
//thuc hien ket noi
$conn=new mysqli($svr,$u,$p,$dbname);
$sql="select * from mytable";//cau lenh
$result=$conn->query($sql);//thuc thi lenh
//doc ket qua
while ($row[]=$result->fetch_assoc())//while(line.ReadLine())
{
    $json=json_encode($row);
}
echo $json;//in ra man hinh
$conn->close();
