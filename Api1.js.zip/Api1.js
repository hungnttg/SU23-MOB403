//b1. Cai dat thu vien
//npm install express --save
//npm install mysql --save
//b2. khai bao doi tuong express
var express=require('express');
var app=express();
var kq="day la ket qua tra ve";
//B3---- doc du lieu tu csdl mysql
var mysql=require('mysql');
var con=mysql.createConnection({
     host:"sql.freedb.tech",
     user:"freedb_hungnq",
     password:"@9hc%!U9jW7Hs!k",
     database:"freedb_hungnq"
});
con.connect((err)=>{
     if(err) throw err;
     con.query("select * from sinhvien",(err,result,fields)=>{
          if(err) throw err;
          kq=JSON.stringify(result);
          console.log(kq);
     });
});
//B4--- tra ve ket qua
app.get('/selectall',function(req,res){
     res.send(kq);
});
//b5-Dua len giao thuc http
var server=app.listen(8000,function(){
     var host=server.address().address;
     var post=server.address().port;
     console.log("server dang lang nghe o: http://&s:%s",host,post);
});
