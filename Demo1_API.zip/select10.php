<?php
//khai bao cac bien
header("Access-Control-Allow-Origin:*");
$s="localhost"; $u="id10840443_user";
$p="12345678Aa@123"; $db="id10840443_springbootdb";
//tao ket noi voi csdl
$con=new mysqli($s,$u,$p,$db);
//tao chuoi truy van
$sql="select * from MyGuests";
//thuc thi lenh
$result=$con->query($sql);//thuc thi va lay ve ket qua
while ($row[]=$result->fetch_assoc())//doc tung dong du lieu
{
    $json=json_encode($row);//chuyen du lieu sang json
}
echo '"MyGuest":{'.$json.'}';
$con->close();
?>