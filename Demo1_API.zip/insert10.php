<?php
//khai bao cac bien
$s="localhost"; $u="id10840443_user";
$p="12345678Aa@123"; $db="id10840443_springbootdb";
//tao ket noi voi csdl
$con=new mysqli($s,$u,$p,$db);
//tao chuoi truy van
$sql="insert into MyGuests (firstname,lastname,email)
 values ('f1','l2','e1')";
//thuc thi lenh
if($con->query($sql)===TRUE){
    echo "Them thanh cong";
}
else
{
    echo "Them that bai";
}
?>