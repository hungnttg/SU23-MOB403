<?php
//khai bao cac bien
$s="localhost"; $u="id10840443_user";
$p="12345678Aa@123"; $db="id10840443_springbootdb";
//tao ket noi voi csdl
$con=new mysqli($s,$u,$p,$db);
//tao chuoi truy van
$sql="delete from MyGuests where id=193";
//thuc thi lenh
if($con->query($sql)===TRUE){
    echo "Xoa thanh cong";
}
else
{
    echo "Xoa that bai";
}
?>