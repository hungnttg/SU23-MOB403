package com.hnq40.myapplication3.demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.myapplication3.R;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class Demo22MainActivity extends AppCompatActivity {
    ImageView imageView;
    TextView textView;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo21_main);
        imageView=findViewById(R.id.demo21Img);
        textView=findViewById(R.id.demo21Tv);
        button=findViewById(R.id.demo22Btn2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Demo22Async().execute("http://tinypic.com/images/goodbye.jpg");
            }
        });
    }
    class Demo22Async extends AsyncTask<String,Void, Bitmap>{
        //doc du lieu tu server
        @Override
        protected Bitmap doInBackground(String... strings) {
            try {
                return BitmapFactory.decodeStream((InputStream) new URL(strings[0]).getContent());
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        //dua du lieu len client
        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            if(bitmap!=null){
                imageView.setImageBitmap(bitmap);
            }
            else {
                textView.setText("Co loi doc du lieu");
            }
        }
    }
}