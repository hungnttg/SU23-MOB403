package com.hnq40.myapplication3.demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.myapplication3.R;
public class Demo21MainActivity extends AppCompatActivity
implements View.OnClickListener,Demo21Interface {
    Button btn;
    ImageView imageView;
    TextView textView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo21_main);
        btn=findViewById(R.id.demo21Btn);
        imageView=findViewById(R.id.demo21Img);
        textView=findViewById(R.id.demo21Tv);
        btn.setOnClickListener(this);
    }
    //click button
    @Override
    public void onClick(View v) {
        new Demo21AsyncTask(this,this)
                .execute("http://tinypic.com/images/goodbye.jpg");
    }
    //lay anh tu interface
    @Override
    public void onLoadAnh(Bitmap bitmap) {
        imageView.setImageBitmap(bitmap);
    }
    //lay loi tu interface
    @Override
    public void onLoi() {
        textView.setText("Loi doc du lieu");
    }
}