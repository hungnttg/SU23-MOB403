package com.hnq40.myapplication3.demo2;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class Demo21AsyncTask extends AsyncTask<String,Void, Bitmap> {
    private  Demo21Interface demo21Interface;
    private Context context;
    //khoi tao
    public Demo21AsyncTask(Demo21Interface demo21Interface, Context context) {
        this.demo21Interface = demo21Interface;
        this.context = context;
    }

    //doc du lieu tu server
    @Override
    protected Bitmap doInBackground(String... strings) {
        try {
            return BitmapFactory.decodeStream((InputStream) new URL(strings[0]).getContent());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    //tra ket qua ve client
    @Override
    protected void onPostExecute(Bitmap bitmap) {
        super.onPostExecute(bitmap);
        if(bitmap!=null){
            demo21Interface.onLoadAnh(bitmap);//tra ve ket qua cho interface
        }
        else {
            demo21Interface.onLoi();//tra ve loi

        }
    }
}
