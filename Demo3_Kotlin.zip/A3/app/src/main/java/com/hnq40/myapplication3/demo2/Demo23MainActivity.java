package com.hnq40.myapplication3.demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.myapplication3.R;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class Demo23MainActivity extends AppCompatActivity {
    TextView textView;
    ImageView imageView;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo21_main);
        textView=findViewById(R.id.demo21Tv);
        imageView=findViewById(R.id.demo21Img);
        button=findViewById(R.id.demo23Btn3);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Thread myTh=new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Bitmap bitmap=loadAnh("http://tinypic.com/images/goodbye.jpg");
                        imageView.post(new Runnable() {
                            @Override
                            public void run() {
                                imageView.setImageBitmap(bitmap);
                                textView.setText("Doc anh bang thread thanh cong");
                            }
                        });
                    }
                });
                myTh.start();
            }
        });
    }
    //ham load anh bang thread
    private Bitmap loadAnh(String link)
    {
        URL url=null;
        Bitmap bitmap=null;
        try {
            url=new URL(link);
            bitmap= BitmapFactory.decodeStream(url.openConnection().getInputStream());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bitmap;
    }
}