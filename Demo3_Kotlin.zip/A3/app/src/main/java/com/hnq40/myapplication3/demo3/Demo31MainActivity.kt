package com.hnq40.myapplication3.demo3

import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView
import android.widget.EditText
import android.annotation.SuppressLint
import android.os.AsyncTask
import android.os.Bundle
import com.hnq40.myapplication3.R
import android.view.View
import android.widget.Button
import java.io.*
import java.lang.StringBuilder
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.URL
import java.net.URLEncoder

class Demo31MainActivity : AppCompatActivity() {
    var tvKQ: TextView? = null
    var txt1: EditText? = null
    var txt2: EditText? = null
    //var btn1: Button? = null
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_demo31_main)
        tvKQ = findViewById(R.id.demo31TvKQ)
        txt1 = findViewById(R.id.demo31Txt1)
        txt2 = findViewById(R.id.demo31Txt2)
        var btn1 = findViewById<Button>(R.id.demo31Btn1)
        btn1.setOnClickListener {
            PostAsync1().execute();
        }

    }
    inner class PostAsync1: AsyncTask<Void?, Void?, Void?>() {
        var pathPost = "https://batdongsanabc.000webhostapp.com/mob403lab3/b3-post.php"
        var ketquapost = ""
        override fun doInBackground(vararg params: Void?): Void? {
            try {
                //1.chuyen path thanh url
                val url = URL(pathPost)
                //2.Ma hoa tham so
                val param = "canh=" + URLEncoder.encode(txt1!!.text.toString(), "utf-8")
                //3. Mo ket noi
                val urlConnection = url.openConnection() as HttpURLConnection
                //4. Thiet lap cac thuoc tinh cho urlConnection
                urlConnection.doOutput = true //co lay du lieu tra ve
                urlConnection.requestMethod = "POST" //su dung phuong thuc post
                urlConnection.setFixedLengthStreamingMode(param.toByteArray().size) //do dai cua tham so
                urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                //5. truyen tham so
                val printWriter = PrintWriter(urlConnection.outputStream)
                printWriter.print(param)
                printWriter.close()
                //6. doc du lieu
                val br = BufferedReader(InputStreamReader(urlConnection.inputStream)) //bo dem
                val stringBuilder = StringBuilder() //bo chua du lieu
                var line: String? = "" //doc theo dong
                while (br.readLine().also { line = it } != null) //neu van con du lieu thi van doc
                {
                    stringBuilder.append(line) //dua du lieu vao bo chua
                }
                ketquapost = stringBuilder.toString() //tra ve ket qua
                urlConnection.disconnect() //dong ket noi
            } catch (e: MalformedURLException) {
                e.printStackTrace()
            } catch (e: UnsupportedEncodingException) {
                e.printStackTrace()
            } catch (e: IOException) {
                e.printStackTrace()
            }
            return null
        }

        override fun onPostExecute(result: Void?) {
            super.onPostExecute(result)
            tvKQ!!.text = ketquapost
        }

    }
    inner class GETAsyn1: AsyncTask<Void, Void, Void>() {
        var pathGet = "https://batdongsanabc.000webhostapp.com/mob403lab3/b3-get.php"
        var ketquaget = ""
        override fun doInBackground(vararg params: Void?): Void? {
            pathGet += "?toan=" + txt1!!.text.toString() + "&van=" + txt2!!.text.toString()
            try {
                //chuyen path thanh url
                val url = URL(pathGet)
                //tao bo dem du lieu
                val br = BufferedReader(InputStreamReader(url.openConnection().getInputStream()))
                //tao bo chua du lieu
                val stringBuilder = StringBuilder()
                //bat dau doc dulieu
                var line: String? = ""
                while (br.readLine().also { line = it } != null) { //neu van con du lieu
                    stringBuilder.append(line) //dua du lieu vao bo chua
                }
                ketquaget = stringBuilder.toString() //tra ve ket qua

            } catch (e: MalformedURLException) {
                e.printStackTrace()
            } catch (e: IOException) {
                e.printStackTrace()
            }
            return null
        }

        override fun onPostExecute(result: Void?) {
            super.onPostExecute(result)
            tvKQ!!.text = ketquaget
        }

    }

}