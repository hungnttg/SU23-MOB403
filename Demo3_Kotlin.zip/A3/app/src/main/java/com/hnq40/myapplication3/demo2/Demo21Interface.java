package com.hnq40.myapplication3.demo2;

import android.graphics.Bitmap;

public interface Demo21Interface {
    void onLoadAnh(Bitmap bitmap);
    void onLoi();
}
