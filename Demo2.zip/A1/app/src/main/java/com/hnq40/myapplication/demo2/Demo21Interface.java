package com.hnq40.myapplication.demo2;

import android.graphics.Bitmap;

public interface Demo21Interface {
    void onLoadAnh(Bitmap bitmap);//ham load anh
    void onLoi();//ham loi
}
