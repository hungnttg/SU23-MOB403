var express = require('express');  
var app = express();  
//----------------------------------ket noi voi db va lay ve ket qua
var result2="";//kq
var mysql=require('mysql');//khai bao thu vien
var con=mysql.createConnection({//khai bao thong tin server
    host:"sql.freedb.tech",
    user:"freedb_hungnq",
    password:"@9hc%!U9jW7Hs!k",
    database: "freedb_hungnq"
});
//ket noi
con.connect((err)=>{
    if(err) throw err;
    con.query("select * from sinhvien",(err,result,fields)=>{
        if(err) throw err;
        //var result1 = JSON.parse(JSON.stringify(result));
        result2 = JSON.stringify(result);
        console.log(result2);
    });
});
//----------------------------------end ket noi voi db va lay ve ket qua
//------in ra ket qua---------
app.get('/', function (req, res) {  
  res.send(result2);  
});  
//------end in ra ket qua---------
//------lang nghe tren http ---------
var server = app.listen(8000, function () {  
  var host = server.address().address;  
  var port = server.address().port;  
  console.log('Server lang nghe tai http://%s:%s', host, port);  
});  