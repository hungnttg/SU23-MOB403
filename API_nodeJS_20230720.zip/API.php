<?php
header('Access-Control-Allow-Origin: *');
//khai bao thong tin server
$ser="localhost"; $u="id10840443_user"; $p="12345678Aa@123";
$dbname="id10840443_springbootdb";
//thuc hien ket noi
$con=new mysqli($ser,$u,$p,$dbname);
//khai bao, thuc thi lenh
$sql="select * from mytable";//khai bao
$result=$con->query($sql);//thuc thi
//doc ket qua
while ($row[]=$result->fetch_assoc())//while(!line.Readline)
{
    $json=json_encode($row);//chuyen sang json
}
echo '{"products":'.$json.'}';
$con->close();
?>